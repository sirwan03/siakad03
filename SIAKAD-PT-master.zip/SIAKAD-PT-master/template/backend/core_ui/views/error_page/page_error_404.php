<div class="flex-row align-items-center" style="min-height: 65vh;display: flex;">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="clearfix">
          <h1 class="float-left display-3 mr-4 text-warning">404</h1>
          <h4 class="pt-3">Oops!</h4>
          <p class="text-muted">Halaman yang anda cari tidak ditemukan.</p>
        </div>
        <div class="input-prepend input-group">
          <div class="input-group-prepend">
            <span class="input-group-text"><i class="fa fa-search"></i></span>
          </div>
          <input id="prependedInput" class="form-control" size="16" type="text" placeholder="Apa yang anda cari?">
          <span class="input-group-append">
            <button class="btn btn-info text-white" disabled="disabled" type="button">Cari</button>
          </span>
        </div>
      </div>
    </div>
  </div>
</div>